$(document).ready(function() {
  // Any animation JS in here
  // Marching roman soldiers? Burning cities?
})